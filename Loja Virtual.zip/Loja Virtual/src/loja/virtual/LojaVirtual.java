package loja.virtual;

public class LojaVirtual {    
    
    public static void main(String[] args) {
        System.out.println("Welcome!");
        Catalogo cat = new Catalogo();
        cat.Listar();

    }
}
