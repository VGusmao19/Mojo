package loja.virtual;

public class Produtos {
    public int ID;
    public String Descricao;
    public double Valor;
    public int QntEstoque; 

    public Produtos(int ID, String Descricao, double Valor, int QntEstoque) {
        this.ID = ID;
        this.Descricao = Descricao;
        this.Valor = Valor;
        this.QntEstoque = QntEstoque;
    }

 
}



